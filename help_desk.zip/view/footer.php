<script src="<?php echo $db->internalUrl("/view") ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo $db->internalUrl("/view") ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo $db->internalUrl("/view") ?>/assets/js/custom.js"></script>
</body>
</html>