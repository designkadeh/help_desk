#App Descriptions & Running
* Change str_replace array[0] according to your system (e.g: $lampp for ubuntu) on Database.php & setup.php internalUrl Method
* Enter ideal database name for create database, tables a Relations
* After success installation your files such as Install.php, Installation.php, db_create.php and setup.php removed automatically
* Then your config.php file renew from your entered Data from Installation
* This project create for tabriz number 1 technical university, Web design lesson
* This project created by Mohammad Taghi Gholami, Developer & programmer at Urmia city in Republic Islamic of Iran
* This Project use switches for routing in view/routing.php
* This Project use ajax for login & Register and use notifications from javascript in assets/js/custom.js
* This project used provided front interface for login from https://bootsnipp.com/snippets/featured/application-login
* All Tables relation has CASCADE
* All Responses Hashed

#App Technologies
* PHP 7 
* HTML 5
* CSS 3
* Animate CSS
* Jquery
* Ajax
* Twitter Bootstrap 3.3.7

#Methods
* construct //for db connection
* disConnect
* curd
* login
* logout
* search
* redirect
* htmlSpecialChars
* realEscapeHtml
* getRows
* multipleJoin //join in 3 table
* internalUrl
* security

#Classes
* Database
* Install
* PDO

#About 
* Email: Info@designkadeh.com
* Web: https://designkadeh.com
* Instagram: designkadeh
* Telegram: designkadehcom